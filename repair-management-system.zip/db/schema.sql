-- Computer Repair & Maintenance Management System — SQLite schema

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('customer','technician','admin')),
  specialization TEXT,            -- technicians only
  availability_status TEXT DEFAULT 'available', -- available / busy / off
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS devices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES users(id),
  type TEXT NOT NULL,             -- laptop, desktop, printer...
  brand TEXT,
  model TEXT,
  serial_no TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS repair_types (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL,
  base_price REAL NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS repair_jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES users(id),
  device_id INTEGER NOT NULL REFERENCES devices(id),
  technician_id INTEGER REFERENCES users(id),
  repair_type_id INTEGER REFERENCES repair_types(id),
  problem_description TEXT NOT NULL,
  priority TEXT DEFAULT 'normal', -- low/normal/high/urgent
  status TEXT NOT NULL DEFAULT 'submitted',
    -- submitted, under_diagnosis, quotation_sent, approved, awaiting_parts,
    -- in_progress, completed, invoiced, paid, closed, cancelled, on_hold
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS job_images (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id INTEGER NOT NULL REFERENCES repair_jobs(id),
  image_path TEXT NOT NULL,
  uploaded_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS diagnoses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id INTEGER NOT NULL REFERENCES repair_jobs(id),
  technician_id INTEGER NOT NULL REFERENCES users(id),
  findings TEXT NOT NULL,
  recommended_action TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS quotations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id INTEGER NOT NULL REFERENCES repair_jobs(id),
  labour_cost REAL DEFAULT 0,
  parts_cost REAL DEFAULT 0,
  total REAL DEFAULT 0,
  status TEXT DEFAULT 'pending', -- pending, approved, rejected
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS spare_parts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  sku TEXT UNIQUE,
  stock_qty INTEGER DEFAULT 0,
  reorder_level INTEGER DEFAULT 5,
  unit_cost REAL DEFAULT 0,
  unit_price REAL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS parts_used (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id INTEGER NOT NULL REFERENCES repair_jobs(id),
  spare_part_id INTEGER NOT NULL REFERENCES spare_parts(id),
  quantity INTEGER NOT NULL,
  unit_price REAL NOT NULL,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS labour_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id INTEGER NOT NULL REFERENCES repair_jobs(id),
  technician_id INTEGER NOT NULL REFERENCES users(id),
  hours REAL NOT NULL,
  rate REAL NOT NULL,
  description TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id INTEGER NOT NULL REFERENCES repair_jobs(id),
  quotation_id INTEGER REFERENCES quotations(id),
  total_amount REAL NOT NULL,
  status TEXT DEFAULT 'unpaid', -- unpaid, paid, partial
  issued_at TEXT DEFAULT (datetime('now')),
  due_date TEXT
);

CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_id INTEGER NOT NULL REFERENCES invoices(id),
  amount REAL NOT NULL,
  method TEXT NOT NULL, -- mpesa, cash, card
  transaction_ref TEXT,
  status TEXT DEFAULT 'pending', -- pending, completed, failed
  paid_at TEXT
);

CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  job_id INTEGER REFERENCES repair_jobs(id),
  type TEXT NOT NULL,
  message TEXT NOT NULL,
  channel TEXT DEFAULT 'app', -- app, sms, email
  read_at TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS status_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id INTEGER NOT NULL REFERENCES repair_jobs(id),
  old_status TEXT,
  new_status TEXT NOT NULL,
  changed_by INTEGER REFERENCES users(id),
  changed_at TEXT DEFAULT (datetime('now'))
);

-- Seed a few repair types
INSERT OR IGNORE INTO repair_types (id, name, base_price) VALUES
  (1, 'Screen Replacement', 4500),
  (2, 'Virus/Malware Removal', 1500),
  (3, 'Hardware Diagnostic', 1000),
  (4, 'OS Reinstall', 2000),
  (5, 'Data Recovery', 3500),
  (6, 'Battery Replacement', 3000);

-- Seed an admin (password: admin123 — hashed at first run by seed script instead)
