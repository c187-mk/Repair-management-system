# RepairHub — Computer Repair & Maintenance Management System

Full-stack app: **Node.js/Express** backend, **SQLite** (via better-sqlite3), **JWT** auth,
vanilla **HTML/CSS/JS** frontend, and an **M-Pesa Daraja STK Push** integration for payments.

## Roles
- **Customer** — register/login, submit a problem with photos, pick a repair type, get a
  quotation, approve it, track status live, pay via M-Pesa, view service history.
- **Technician** — see assigned jobs, submit a diagnosis, send a quotation, update status,
  log parts used (deducts stock) and labour, complete the job.
- **Admin** — manage customers/technicians, assign jobs, manage spare parts inventory,
  generate invoices, reconcile payments, view revenue, and pull reports (turnaround time,
  technician performance, parts usage).

## Quick start

```bash
npm install
cp .env.example .env        # fill in JWT_SECRET and (optionally) M-Pesa sandbox creds
npm run seed                 # creates a default admin + technician + sample spare parts
npm start                    # http://localhost:3000
```

Demo logins after seeding:
- Admin: `admin@repairsys.local` / `admin123`
- Technician: `tech1@repairsys.local` / `tech123`
- Customers: register your own at `/register.html`

## Project layout
```
server.js              Express app entrypoint
db/schema.sql           SQLite schema (13 tables — see design doc)
db/db.js                DB connection + auto-migrate on boot
db/seed.js               Seeds admin/technician/sample parts
middleware/auth.js       JWT auth + role guard middleware
routes/auth.js           Register/login
routes/jobs.js            Job lifecycle: submit, images, diagnosis, status, parts, labour
routes/finance.js         Quotations, invoices, payments (incl. M-Pesa STK push + callback)
routes/admin.js          Users, spare parts, revenue, reports
routes/misc.js            Notifications feed, service history
utils/mpesa.js            Daraja OAuth + STK Push + phone normalization
utils/notifications.js    In-app notification writer (SMS/email are stubbed — swap in
                           Africa's Talking / SMTP in production)
public/                  Frontend (login, register, dashboards per role, job tracking page)
uploads/                 Job photos land here (served at /uploads/*)
```

## Repair job status pipeline
```
submitted → under_diagnosis → quotation_sent → approved
  → awaiting_parts (optional) → in_progress → completed
  → invoiced → paid → closed
        ↘ (from most stages) → cancelled / on_hold
```
Every transition is validated server-side (`routes/jobs.js: VALID_TRANSITIONS`), logged to
`status_history`, and fires a customer notification.

## M-Pesa setup
1. Get sandbox credentials from https://developer.safaricom.co.ke
2. Fill `MPESA_CONSUMER_KEY`, `MPESA_CONSUMER_SECRET`, `MPESA_PASSKEY` in `.env`
   (the sandbox shortcode `174379` and passkey are on the Daraja test credentials page)
3. Expose your local server with ngrok and set `MPESA_CALLBACK_URL` to
   `https://<your-ngrok>.ngrok.io/api/payments/mpesa/callback`
4. Customer taps "Pay with M-Pesa" on a job's invoice → STK prompt hits their phone →
   Daraja calls the callback → payment + invoice + job flip to paid automatically.

## Notes & next steps
- SQLite is fine for a single-server MVP; move to PostgreSQL if you expect concurrent
  writes at scale (e.g. many technicians updating stock simultaneously).
- SMS/email notifications are stubbed to console.log — wire `utils/notifications.js` to
  Africa's Talking (SMS) and SMTP/Resend (email) for production.
- No public "browse repair types" endpoint was added for brevity — add
  `GET /api/repair-types` (no auth) if you want the submit-job dropdown populated live.
- File uploads are stored on local disk; swap to S3-compatible storage if you deploy
  somewhere without a persistent filesystem.
