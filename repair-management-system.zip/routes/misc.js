const express = require('express');
const db = require('../db/db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

// Notifications for the logged-in user
router.get('/notifications', authenticate, (req, res) => {
  const rows = db
    .prepare(`SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50`)
    .all(req.user.id);
  res.json(rows);
});

router.patch('/notifications/:id/read', authenticate, (req, res) => {
  db.prepare(`UPDATE notifications SET read_at = datetime('now') WHERE id = ? AND user_id = ?`)
    .run(req.params.id, req.user.id);
  res.json({ ok: true });
});

// Customer: full service history (past jobs + devices + invoices)
router.get('/service-history', authenticate, (req, res) => {
  const jobs = db
    .prepare(
      `SELECT rj.id as job_id, rj.status, rj.problem_description, rj.created_at, rj.updated_at,
              d.type as device_type, d.brand, d.model,
              inv.id as invoice_id, inv.total_amount, inv.status as invoice_status
       FROM repair_jobs rj
       JOIN devices d ON d.id = rj.device_id
       LEFT JOIN invoices inv ON inv.job_id = rj.id
       WHERE rj.customer_id = ?
       ORDER BY rj.created_at DESC`
    )
    .all(req.user.id);
  res.json(jobs);
});

module.exports = router;
