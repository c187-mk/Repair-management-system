const API = {
  base: '/api',
  token: () => localStorage.getItem('token'),
  user: () => JSON.parse(localStorage.getItem('user') || 'null'),

  async req(method, path, body, isForm = false) {
    const headers = {};
    if (this.token()) headers['Authorization'] = `Bearer ${this.token()}`;
    if (!isForm) headers['Content-Type'] = 'application/json';

    const res = await fetch(this.base + path, {
      method,
      headers,
      body: body ? (isForm ? body : JSON.stringify(body)) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
    return data;
  },

  get(path) { return this.req('GET', path); },
  post(path, body, isForm) { return this.req('POST', path, body, isForm); },
  patch(path, body) { return this.req('PATCH', path, body); },
  del(path) { return this.req('DELETE', path); },
};

function requireAuth(allowedRoles) {
  const user = API.user();
  if (!user || !API.token()) {
    window.location.href = '/login.html';
    return null;
  }
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    alert('You do not have access to this page.');
    window.location.href = '/login.html';
    return null;
  }
  return user;
}

function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  window.location.href = '/login.html';
}

function statusLabel(s) { return (s || '').replace(/_/g, ' '); }
function money(n) { return 'KES ' + Number(n || 0).toLocaleString(); }
