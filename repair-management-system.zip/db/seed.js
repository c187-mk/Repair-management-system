const bcrypt = require('bcryptjs');
const db = require('./db');

async function seed() {
  const admin = db.prepare(`SELECT id FROM users WHERE email = ?`).get('admin@repairsys.local');
  if (!admin) {
    const hash = await bcrypt.hash('admin123', 10);
    db.prepare(
      `INSERT INTO users (name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, 'admin')`
    ).run('System Admin', 'admin@repairsys.local', '254700000000', hash);
    console.log('Created admin: admin@repairsys.local / admin123');
  }

  const tech = db.prepare(`SELECT id FROM users WHERE email = ?`).get('tech1@repairsys.local');
  if (!tech) {
    const hash = await bcrypt.hash('tech123', 10);
    db.prepare(
      `INSERT INTO users (name, email, phone, password_hash, role, specialization) VALUES (?, ?, ?, ?, 'technician', ?)`
    ).run('Jane Mwangi', 'tech1@repairsys.local', '254700000001', hash, 'Hardware & Screens');
    console.log('Created technician: tech1@repairsys.local / tech123');
  }

  const parts = db.prepare(`SELECT COUNT(*) as c FROM spare_parts`).get();
  if (parts.c === 0) {
    const insert = db.prepare(
      `INSERT INTO spare_parts (name, sku, stock_qty, reorder_level, unit_cost, unit_price) VALUES (?, ?, ?, ?, ?, ?)`
    );
    insert.run('15.6" LCD Screen', 'SCR-156', 10, 3, 3200, 4500);
    insert.run('Laptop Battery (Generic)', 'BAT-GEN', 15, 5, 1800, 3000);
    insert.run('SSD 256GB', 'SSD-256', 20, 5, 2500, 3500);
    insert.run('RAM 8GB DDR4', 'RAM-8G', 25, 5, 1800, 2600);
    console.log('Seeded spare parts');
  }
}

seed().then(() => process.exit(0));
