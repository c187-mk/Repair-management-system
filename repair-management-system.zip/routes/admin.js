const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db/db');
const { authenticate, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate, requireRole('admin'));

// --- Manage customers & technicians ---
router.get('/users', (req, res) => {
  const { role } = req.query;
  const rows = role
    ? db.prepare(`SELECT id, name, email, phone, role, specialization, availability_status, created_at FROM users WHERE role = ?`).all(role)
    : db.prepare(`SELECT id, name, email, phone, role, specialization, availability_status, created_at FROM users`).all();
  res.json(rows);
});

router.post('/technicians', async (req, res) => {
  const { name, email, phone, password, specialization } = req.body;
  const hash = await bcrypt.hash(password, 10);
  const info = db
    .prepare(`INSERT INTO users (name, email, phone, password_hash, role, specialization) VALUES (?, ?, ?, ?, 'technician', ?)`)
    .run(name, email, phone, hash, specialization || null);
  res.status(201).json({ id: info.lastInsertRowid });
});

router.delete('/users/:id', (req, res) => {
  db.prepare(`DELETE FROM users WHERE id = ?`).run(req.params.id);
  res.json({ ok: true });
});

// --- Spare parts inventory ---
router.get('/spare-parts', (req, res) => {
  res.json(db.prepare(`SELECT * FROM spare_parts ORDER BY name`).all());
});

router.post('/spare-parts', (req, res) => {
  const { name, sku, stock_qty = 0, reorder_level = 5, unit_cost = 0, unit_price = 0 } = req.body;
  const info = db
    .prepare(`INSERT INTO spare_parts (name, sku, stock_qty, reorder_level, unit_cost, unit_price) VALUES (?, ?, ?, ?, ?, ?)`)
    .run(name, sku || null, stock_qty, reorder_level, unit_cost, unit_price);
  res.status(201).json({ id: info.lastInsertRowid });
});

router.patch('/spare-parts/:id', (req, res) => {
  const fields = ['name', 'sku', 'stock_qty', 'reorder_level', 'unit_cost', 'unit_price'];
  const updates = fields.filter((f) => f in req.body);
  if (!updates.length) return res.status(400).json({ error: 'No valid fields to update' });
  const setClause = updates.map((f) => `${f} = ?`).join(', ');
  db.prepare(`UPDATE spare_parts SET ${setClause} WHERE id = ?`).run(...updates.map((f) => req.body[f]), req.params.id);
  res.json({ ok: true });
});

router.get('/spare-parts/low-stock', (req, res) => {
  res.json(db.prepare(`SELECT * FROM spare_parts WHERE stock_qty <= reorder_level`).all());
});

// --- Repair type catalog ---
router.post('/repair-types', (req, res) => {
  const { name, base_price } = req.body;
  const info = db.prepare(`INSERT INTO repair_types (name, base_price) VALUES (?, ?)`).run(name, base_price);
  res.status(201).json({ id: info.lastInsertRowid });
});

// --- Revenue & reports ---
router.get('/revenue', (req, res) => {
  const { from, to } = req.query;
  const range = from && to ? `WHERE paid_at BETWEEN ? AND ?` : '';
  const params = from && to ? [from, to] : [];
  const total = db
    .prepare(`SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE status = 'completed' ${range ? 'AND paid_at BETWEEN ? AND ?' : ''}`)
    .get(...params);
  const byMethod = db
    .prepare(`SELECT method, COALESCE(SUM(amount),0) as total, COUNT(*) as count FROM payments WHERE status = 'completed' GROUP BY method`)
    .all();
  res.json({ total: total.total, byMethod });
});

router.get('/reports/turnaround', (req, res) => {
  // avg days from submitted to closed, per repair type
  const rows = db
    .prepare(
      `SELECT rt.name as repair_type,
              AVG(julianday(rj.updated_at) - julianday(rj.created_at)) as avg_days,
              COUNT(*) as job_count
       FROM repair_jobs rj
       LEFT JOIN repair_types rt ON rt.id = rj.repair_type_id
       WHERE rj.status IN ('closed','paid')
       GROUP BY rj.repair_type_id`
    )
    .all();
  res.json(rows);
});

router.get('/reports/technician-performance', (req, res) => {
  const rows = db
    .prepare(
      `SELECT u.id, u.name,
              COUNT(rj.id) as jobs_handled,
              SUM(CASE WHEN rj.status IN ('closed','paid') THEN 1 ELSE 0 END) as jobs_completed
       FROM users u
       LEFT JOIN repair_jobs rj ON rj.technician_id = u.id
       WHERE u.role = 'technician'
       GROUP BY u.id`
    )
    .all();
  res.json(rows);
});

router.get('/reports/parts-usage', (req, res) => {
  const rows = db
    .prepare(
      `SELECT sp.name, SUM(pu.quantity) as total_used, SUM(pu.quantity * pu.unit_price) as total_value
       FROM parts_used pu JOIN spare_parts sp ON sp.id = pu.spare_part_id
       GROUP BY pu.spare_part_id ORDER BY total_used DESC`
    )
    .all();
  res.json(rows);
});

module.exports = router;
