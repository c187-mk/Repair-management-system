const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const db = require('../db/db');
const { authenticate, requireRole } = require('../middleware/auth');
const { notify } = require('../utils/notifications');

const router = express.Router();

const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) =>
    cb(null, `${Date.now()}-${Math.round(Math.random() * 1e9)}${path.extname(file.originalname)}`),
});
const upload = multer({
  storage,
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith('image/')) return cb(new Error('Only image uploads allowed'));
    cb(null, true);
  },
});

const VALID_TRANSITIONS = {
  submitted: ['under_diagnosis', 'cancelled'],
  under_diagnosis: ['quotation_sent', 'on_hold', 'cancelled'],
  quotation_sent: ['approved', 'cancelled', 'on_hold'],
  approved: ['awaiting_parts', 'in_progress'],
  awaiting_parts: ['in_progress'],
  in_progress: ['completed', 'on_hold'],
  completed: ['invoiced'],
  invoiced: ['paid'],
  paid: ['closed'],
  on_hold: ['under_diagnosis', 'in_progress', 'cancelled'],
};

function changeStatus(jobId, newStatus, changedBy) {
  const job = db.prepare(`SELECT * FROM repair_jobs WHERE id = ?`).get(jobId);
  if (!job) throw { code: 404, msg: 'Job not found' };
  const allowed = VALID_TRANSITIONS[job.status] || [];
  if (!allowed.includes(newStatus)) {
    throw { code: 400, msg: `Cannot move from '${job.status}' to '${newStatus}'` };
  }
  db.prepare(`UPDATE repair_jobs SET status = ?, updated_at = datetime('now') WHERE id = ?`).run(
    newStatus,
    jobId
  );
  db.prepare(
    `INSERT INTO status_history (job_id, old_status, new_status, changed_by) VALUES (?, ?, ?, ?)`
  ).run(jobId, job.status, newStatus, changedBy);
  notify(
    job.customer_id,
    jobId,
    'status_update',
    `Your repair job #${jobId} status changed to "${newStatus.replace('_', ' ')}"`
  );
  return newStatus;
}

// Customer: submit a new job (device + problem description)
router.post('/', authenticate, requireRole('customer'), (req, res) => {
  const { device, problem_description, repair_type_id, priority } = req.body;
  if (!device || !problem_description) {
    return res.status(400).json({ error: 'device and problem_description are required' });
  }
  const deviceInfo = db
    .prepare(`INSERT INTO devices (customer_id, type, brand, model, serial_no) VALUES (?, ?, ?, ?, ?)`)
    .run(req.user.id, device.type, device.brand || null, device.model || null, device.serial_no || null);

  const jobInfo = db
    .prepare(
      `INSERT INTO repair_jobs (customer_id, device_id, repair_type_id, problem_description, priority)
       VALUES (?, ?, ?, ?, ?)`
    )
    .run(req.user.id, deviceInfo.lastInsertRowid, repair_type_id || null, problem_description, priority || 'normal');

  db.prepare(`INSERT INTO status_history (job_id, old_status, new_status, changed_by) VALUES (?, NULL, 'submitted', ?)`)
    .run(jobInfo.lastInsertRowid, req.user.id);

  res.status(201).json({ jobId: jobInfo.lastInsertRowid, status: 'submitted' });
});

// Upload photos for a job
router.post('/:id/images', authenticate, upload.array('images', 6), (req, res) => {
  const jobId = req.params.id;
  const job = db.prepare(`SELECT * FROM repair_jobs WHERE id = ?`).get(jobId);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  if (req.user.role === 'customer' && job.customer_id !== req.user.id) {
    return res.status(403).json({ error: 'Not your job' });
  }
  const inserted = (req.files || []).map((f) => {
    const info = db
      .prepare(`INSERT INTO job_images (job_id, image_path) VALUES (?, ?)`)
      .run(jobId, `/uploads/${f.filename}`);
    return { id: info.lastInsertRowid, path: `/uploads/${f.filename}` };
  });
  res.status(201).json({ images: inserted });
});

// List jobs — scoped by role
router.get('/', authenticate, (req, res) => {
  let rows;
  if (req.user.role === 'customer') {
    rows = db.prepare(`SELECT * FROM repair_jobs WHERE customer_id = ? ORDER BY created_at DESC`).all(req.user.id);
  } else if (req.user.role === 'technician') {
    rows = db.prepare(`SELECT * FROM repair_jobs WHERE technician_id = ? ORDER BY created_at DESC`).all(req.user.id);
  } else {
    rows = db.prepare(`SELECT * FROM repair_jobs ORDER BY created_at DESC`).all();
  }
  res.json(rows);
});

// Job detail — device, images, diagnosis, quotation, status history
router.get('/:id', authenticate, (req, res) => {
  const job = db.prepare(`SELECT * FROM repair_jobs WHERE id = ?`).get(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  if (req.user.role === 'customer' && job.customer_id !== req.user.id) {
    return res.status(403).json({ error: 'Not your job' });
  }
  if (req.user.role === 'technician' && job.technician_id !== req.user.id) {
    return res.status(403).json({ error: 'Not assigned to you' });
  }
  const device = db.prepare(`SELECT * FROM devices WHERE id = ?`).get(job.device_id);
  const images = db.prepare(`SELECT * FROM job_images WHERE job_id = ?`).all(job.id);
  const diagnosis = db.prepare(`SELECT * FROM diagnoses WHERE job_id = ? ORDER BY id DESC LIMIT 1`).get(job.id);
  const quotation = db.prepare(`SELECT * FROM quotations WHERE job_id = ? ORDER BY id DESC LIMIT 1`).get(job.id);
  const parts = db.prepare(`SELECT pu.*, sp.name FROM parts_used pu JOIN spare_parts sp ON sp.id = pu.spare_part_id WHERE job_id = ?`).all(job.id);
  const labour = db.prepare(`SELECT * FROM labour_entries WHERE job_id = ?`).all(job.id);
  const history = db.prepare(`SELECT * FROM status_history WHERE job_id = ? ORDER BY changed_at ASC`).all(job.id);
  const invoice = db.prepare(`SELECT * FROM invoices WHERE job_id = ? ORDER BY id DESC LIMIT 1`).get(job.id);

  res.json({ job, device, images, diagnosis, quotation, parts, labour, history, invoice });
});

// Admin: assign a technician
router.patch('/:id/assign', authenticate, requireRole('admin'), (req, res) => {
  const { technician_id } = req.body;
  const tech = db.prepare(`SELECT * FROM users WHERE id = ? AND role = 'technician'`).get(technician_id);
  if (!tech) return res.status(400).json({ error: 'Invalid technician_id' });
  db.prepare(`UPDATE repair_jobs SET technician_id = ? WHERE id = ?`).run(technician_id, req.params.id);
  notify(technician_id, req.params.id, 'job_assigned', `You have been assigned repair job #${req.params.id}`);
  res.json({ ok: true });
});

// Technician: submit diagnosis (also advances status to under_diagnosis if needed)
router.post('/:id/diagnosis', authenticate, requireRole('technician'), (req, res) => {
  const { findings, recommended_action } = req.body;
  const job = db.prepare(`SELECT * FROM repair_jobs WHERE id = ?`).get(req.params.id);
  if (!job || job.technician_id !== req.user.id) return res.status(403).json({ error: 'Not your job' });

  db.prepare(`INSERT INTO diagnoses (job_id, technician_id, findings, recommended_action) VALUES (?, ?, ?, ?)`)
    .run(req.params.id, req.user.id, findings, recommended_action || null);

  if (job.status === 'submitted') changeStatus(req.params.id, 'under_diagnosis', req.user.id);
  res.status(201).json({ ok: true });
});

// Technician/Admin: change status along the valid pipeline
router.patch('/:id/status', authenticate, requireRole('technician', 'admin'), (req, res) => {
  const { status } = req.body;
  try {
    const newStatus = changeStatus(req.params.id, status, req.user.id);
    res.json({ status: newStatus });
  } catch (e) {
    res.status(e.code || 500).json({ error: e.msg || 'Failed to change status' });
  }
});

// Technician: record parts used (deducts stock)
router.post('/:id/parts', authenticate, requireRole('technician'), (req, res) => {
  const { spare_part_id, quantity } = req.body;
  const part = db.prepare(`SELECT * FROM spare_parts WHERE id = ?`).get(spare_part_id);
  if (!part) return res.status(400).json({ error: 'Invalid spare_part_id' });
  if (part.stock_qty < quantity) return res.status(400).json({ error: 'Insufficient stock' });

  db.prepare(`INSERT INTO parts_used (job_id, spare_part_id, quantity, unit_price) VALUES (?, ?, ?, ?)`)
    .run(req.params.id, spare_part_id, quantity, part.unit_price);
  db.prepare(`UPDATE spare_parts SET stock_qty = stock_qty - ? WHERE id = ?`).run(quantity, spare_part_id);

  res.status(201).json({ ok: true });
});

// Technician: record labour
router.post('/:id/labour', authenticate, requireRole('technician'), (req, res) => {
  const { hours, rate, description } = req.body;
  db.prepare(`INSERT INTO labour_entries (job_id, technician_id, hours, rate, description) VALUES (?, ?, ?, ?, ?)`)
    .run(req.params.id, req.user.id, hours, rate, description || null);
  res.status(201).json({ ok: true });
});

module.exports = router;
