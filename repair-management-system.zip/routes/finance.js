const express = require('express');
const db = require('../db/db');
const { authenticate, requireRole } = require('../middleware/auth');
const { notify } = require('../utils/notifications');
const { stkPush } = require('../utils/mpesa');

const router = express.Router();

// --- Quotations ---

// Technician/Admin: create a quotation for a job
router.post('/jobs/:id/quotation', authenticate, requireRole('technician', 'admin'), (req, res) => {
  const { labour_cost = 0, parts_cost = 0 } = req.body;
  const total = Number(labour_cost) + Number(parts_cost);
  const info = db
    .prepare(`INSERT INTO quotations (job_id, labour_cost, parts_cost, total) VALUES (?, ?, ?, ?)`)
    .run(req.params.id, labour_cost, parts_cost, total);

  db.prepare(`UPDATE repair_jobs SET status = 'quotation_sent', updated_at = datetime('now') WHERE id = ? AND status IN ('under_diagnosis','submitted')`)
    .run(req.params.id);

  const job = db.prepare(`SELECT * FROM repair_jobs WHERE id = ?`).get(req.params.id);
  notify(job.customer_id, job.id, 'quote_ready', `Quotation ready for job #${job.id}: KES ${total}`);
  res.status(201).json({ quotationId: info.lastInsertRowid, total });
});

// Customer: approve or reject a quotation
router.patch('/quotations/:id/decision', authenticate, requireRole('customer'), (req, res) => {
  const { decision } = req.body; // 'approved' | 'rejected'
  if (!['approved', 'rejected'].includes(decision)) {
    return res.status(400).json({ error: 'decision must be approved or rejected' });
  }
  const quote = db.prepare(`SELECT * FROM quotations WHERE id = ?`).get(req.params.id);
  if (!quote) return res.status(404).json({ error: 'Quotation not found' });

  db.prepare(`UPDATE quotations SET status = ? WHERE id = ?`).run(decision, req.params.id);

  if (decision === 'approved') {
    db.prepare(`UPDATE repair_jobs SET status = 'approved', updated_at = datetime('now') WHERE id = ?`).run(quote.job_id);
  } else {
    db.prepare(`UPDATE repair_jobs SET status = 'cancelled', updated_at = datetime('now') WHERE id = ?`).run(quote.job_id);
  }
  res.json({ ok: true, decision });
});

// --- Invoices ---

// Admin: generate an invoice once a job is completed
router.post('/jobs/:id/invoice', authenticate, requireRole('admin', 'technician'), (req, res) => {
  const job = db.prepare(`SELECT * FROM repair_jobs WHERE id = ?`).get(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  const quote = db.prepare(`SELECT * FROM quotations WHERE job_id = ? ORDER BY id DESC LIMIT 1`).get(job.id);
  if (!quote) return res.status(400).json({ error: 'No quotation on file for this job' });

  const info = db
    .prepare(`INSERT INTO invoices (job_id, quotation_id, total_amount, due_date) VALUES (?, ?, ?, date('now', '+7 day'))`)
    .run(job.id, quote.id, quote.total);

  db.prepare(`UPDATE repair_jobs SET status = 'invoiced', updated_at = datetime('now') WHERE id = ?`).run(job.id);
  notify(job.customer_id, job.id, 'invoice_ready', `Invoice #${info.lastInsertRowid} issued for job #${job.id}: KES ${quote.total}`);
  res.status(201).json({ invoiceId: info.lastInsertRowid, total: quote.total });
});

router.get('/invoices/:id', authenticate, (req, res) => {
  const invoice = db.prepare(`SELECT * FROM invoices WHERE id = ?`).get(req.params.id);
  if (!invoice) return res.status(404).json({ error: 'Not found' });
  const payments = db.prepare(`SELECT * FROM payments WHERE invoice_id = ?`).all(invoice.id);
  res.json({ invoice, payments });
});

// --- Payments ---

// Customer: pay via M-Pesa STK Push
router.post('/invoices/:id/pay/mpesa', authenticate, requireRole('customer'), async (req, res) => {
  const { phone } = req.body;
  const invoice = db.prepare(`SELECT * FROM invoices WHERE id = ?`).get(req.params.id);
  if (!invoice) return res.status(404).json({ error: 'Invoice not found' });

  try {
    const result = await stkPush({
      phone,
      amount: invoice.total_amount,
      accountReference: `INV-${invoice.id}`,
      description: `Repair invoice #${invoice.id}`,
    });
    db.prepare(`INSERT INTO payments (invoice_id, amount, method, transaction_ref, status) VALUES (?, ?, 'mpesa', ?, 'pending')`)
      .run(invoice.id, invoice.total_amount, result.CheckoutRequestID || null);
    res.json({ ok: true, checkoutRequestId: result.CheckoutRequestID, raw: result });
  } catch (err) {
    res.status(502).json({ error: 'STK push failed', detail: err.message });
  }
});

// M-Pesa Daraja calls this after the customer completes/cancels the prompt
router.post('/payments/mpesa/callback', express.json(), (req, res) => {
  const cb = req.body?.Body?.stkCallback;
  if (!cb) return res.status(400).json({ error: 'Malformed callback' });

  const payment = db.prepare(`SELECT * FROM payments WHERE transaction_ref = ?`).get(cb.CheckoutRequestID);
  if (!payment) return res.status(200).json({ ok: true }); // ack anyway

  if (cb.ResultCode === 0) {
    db.prepare(`UPDATE payments SET status = 'completed', paid_at = datetime('now') WHERE id = ?`).run(payment.id);
    db.prepare(`UPDATE invoices SET status = 'paid' WHERE id = ?`).run(payment.invoice_id);
    const invoice = db.prepare(`SELECT * FROM invoices WHERE id = ?`).get(payment.invoice_id);
    db.prepare(`UPDATE repair_jobs SET status = 'paid', updated_at = datetime('now') WHERE id = ?`).run(invoice.job_id);
    const job = db.prepare(`SELECT * FROM repair_jobs WHERE id = ?`).get(invoice.job_id);
    notify(job.customer_id, job.id, 'payment_received', `Payment received for invoice #${invoice.id}. Thank you!`);
  } else {
    db.prepare(`UPDATE payments SET status = 'failed' WHERE id = ?`).run(payment.id);
  }
  res.status(200).json({ ok: true });
});

// Admin: record a manual (cash/card) payment
router.post('/invoices/:id/pay/manual', authenticate, requireRole('admin'), (req, res) => {
  const { amount, method } = req.body;
  const invoice = db.prepare(`SELECT * FROM invoices WHERE id = ?`).get(req.params.id);
  if (!invoice) return res.status(404).json({ error: 'Invoice not found' });

  db.prepare(`INSERT INTO payments (invoice_id, amount, method, status, paid_at) VALUES (?, ?, ?, 'completed', datetime('now'))`)
    .run(invoice.id, amount, method);
  db.prepare(`UPDATE invoices SET status = 'paid' WHERE id = ?`).run(invoice.id);
  db.prepare(`UPDATE repair_jobs SET status = 'paid', updated_at = datetime('now') WHERE id = ?`).run(invoice.job_id);

  res.json({ ok: true });
});

module.exports = router;
