const db = require('../db/db');

/**
 * Creates an in-app notification record and logs where an SMS/email
 * would be sent. Wire sendSms()/sendEmail() to Africa's Talking / SMTP
 * in production — kept as stubs so the app runs with zero external deps.
 */
function notify(userId, jobId, type, message, channel = 'app') {
  db.prepare(
    `INSERT INTO notifications (user_id, job_id, type, message, channel) VALUES (?, ?, ?, ?, ?)`
  ).run(userId, jobId, type, message, channel);

  if (channel === 'sms') sendSms(userId, message);
  if (channel === 'email') sendEmail(userId, message);
}

function sendSms(userId, message) {
  console.log(`[SMS STUB] to user ${userId}: ${message}`);
}

function sendEmail(userId, message) {
  console.log(`[EMAIL STUB] to user ${userId}: ${message}`);
}

module.exports = { notify };
